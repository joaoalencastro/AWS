# Udacity's Project 2
## Udagram

Made by: João Fiuza de Alencastro
This project is a result of the knowledge gained in the Infrastructure as Code section of the Udacity's Cloud DevOps Engineer course.

The URL for the Web application is
http://Proje-LoadB-1ICFLQWUK6UJ5-1504244949.us-east-1.elb.amazonaws.com
The URL can also be found in the output section of the YAML file.